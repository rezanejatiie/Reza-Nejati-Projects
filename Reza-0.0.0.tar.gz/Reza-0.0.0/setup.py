from setuptools import setup

setup(name='Reza',
     packages=['measure2']
)