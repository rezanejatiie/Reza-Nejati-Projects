#print('Reza')


def ali():
  print("ALI")

def reza(naa):
  print(naa)


   
# python helloworld.py   from mypackage.aaa import ali()